			2013-12-23 v1.0
Initial version, support usb-serial driver and google's usb driver(adb, mtp, fastboot...)
			2014-03-05 v1.1
1,add a new composite driver adb+acm, acm will used for modem trace;
2,rename the driver guide from chinese words to english words
			2014-09-01 v1.2
1,update the version number and fix some issues that install fail on some win8 version.
			2014-10-16 v1.3
update mtp driver, and add the pid,vid for single mtp function.

